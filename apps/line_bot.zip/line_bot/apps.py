from django.apps import AppConfig


class LineBotConfig(AppConfig):
    name = 'apps.line_bot'
    verbose_name='movie_linebot'
